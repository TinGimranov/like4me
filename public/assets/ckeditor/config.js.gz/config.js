FCKConfig.EnterMode = 'br' ;
FCKConfig.ShiftEnterMode = 'p' ;
