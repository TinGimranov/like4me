tinyMCE.addI18n('pt.uploadimage', {
  desc: 'Inserir uma imagem do seu computador'
});
