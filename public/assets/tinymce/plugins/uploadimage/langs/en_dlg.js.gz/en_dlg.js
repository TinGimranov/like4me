tinyMCE.addI18n('en.uploadimage_dlg', {
  title: 'Insert image',
  header: "Insert image",
  input:  "Choose an image",
  insert: "Insert",
  cancel: "Cancel"
});
