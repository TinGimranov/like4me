tinyMCE.addI18n('ru.uploadimage_dlg', {
  title: 'Вставить изображение',
  header: "Вставить изображение",
  input:  "Выберите изображение",
  insert: "Вставить",
  cancel: "Отмена"
});
