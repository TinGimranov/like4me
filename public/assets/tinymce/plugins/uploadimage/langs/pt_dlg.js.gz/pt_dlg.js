tinyMCE.addI18n('pt.uploadimage_dlg', {
  title: 'Inserir imagem',
  header: "Inserir imagem",
  input:  "Escolher uma imagem",
  insert: "Inserir",
  cancel: "Cancelar"
});
